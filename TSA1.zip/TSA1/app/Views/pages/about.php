<?= view('header', ['title' => 'About']) ?>

<h2>About This System</h2>

<p>
    The Tasks for Today Management System helps users
    view daily tasks and manage task information.
</p>

<h3>Developer Information</h3>
<p><strong>Developer:</strong> Rafael Palima</p>
<p><strong>Course:</strong> IT0049 - Web System Technologies</p>

<?= view('footer') ?>

<?= view('header', ['title' => 'User Profile']) ?>

<h2>Demo User Profile</h2>

<?php if ($user): ?>
    <p><strong>Username:</strong>
        <?= esc($user['username']) ?></p>

    <p><strong>Full Name:</strong>
        <?= esc($user['full_name']) ?></p>

    <p><strong>Email:</strong>
        <?= esc($user['email']) ?></p>

    <p><strong>Created At:</strong>
        <?= esc($user['created_at']) ?></p>
<?php else: ?>
    <p>No user record found.</p>
<?php endif; ?>

<?= view('footer') ?>

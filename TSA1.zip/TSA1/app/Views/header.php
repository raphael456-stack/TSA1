<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= esc($title ?? 'Tasks for Today') ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 1000px;
            margin: 30px auto;
            padding: 0 20px;
            background: #f5f7fa;
            color: #222;
        }
        nav {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
            background: #243b55;
            padding: 16px;
            border-radius: 8px;
        }
        nav a {
            color: white;
            text-decoration: none;
        }
        main {
            background: white;
            padding: 24px;
            margin-top: 20px;
            border-radius: 8px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background: #e8eef5;
        }
    </style>
</head>
<body>
    <h1>Tasks for Today Management System</h1>

    <nav>
        <a href="<?= site_url('/') ?>">Welcome</a>
        <a href="<?= site_url('tasks') ?>">Task List</a>
        <a href="<?= site_url('profile') ?>">Profile</a>
        <a href="<?= site_url('about') ?>">About</a>
    </nav>

    <main>
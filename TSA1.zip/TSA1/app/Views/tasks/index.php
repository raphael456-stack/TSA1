<?= view('header', ['title' => 'Full Task List']) ?>

<h2>All Tasks</h2>
<p>Complete list of tasks, ordered by date.</p>

<?php if (empty($tasks)): ?>
    <p>No tasks found.</p>
<?php else: ?>
    <table>
        <tr>
            <th>ID</th>
            <th>Task</th>
            <th>Status</th>
            <th>Date</th>
        </tr>

        <?php foreach ($tasks as $task): ?>
            <tr>
                <td><?= esc($task['id']) ?></td>
                <td><?= esc($task['title']) ?></td>
                <td><?= esc($task['status']) ?></td>
                <td><?= esc($task['task_date']) ?></td>
            </tr>
        <?php endforeach; ?>
    </table>
<?php endif; ?>

<?= view('footer') ?>

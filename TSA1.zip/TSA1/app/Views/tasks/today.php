<?= view('header', ['title' => 'Welcome - Tasks for Today']) ?>

<h2>Welcome — Today's Tasks</h2>
<p>Tasks scheduled for <?= date('F j, Y') ?>.</p>

<?php if (empty($tasks)): ?>
    <p>No tasks scheduled for today.</p>
<?php else: ?>
    <table>
        <tr>
            <th>Task</th>
            <th>Status</th>
            <th>Date</th>
        </tr>

        <?php foreach ($tasks as $task): ?>
            <tr>
                <td><?= esc($task['title']) ?></td>
                <td><?= esc($task['status']) ?></td>
                <td><?= esc($task['task_date']) ?></td>
            </tr>
        <?php endforeach; ?>
    </table>
<?php endif; ?>

<?= view('footer') ?>
